"""
快捷指令大全 v6.0 - 最终稳定版
黑底绿字黑客风格 | 无残影按钮 | 丝滑动画 | 中英双语
全部使用广泛兼容命令，兼容 Win7/Win10/Win11
打包: pyinstaller --onefile --windowed --name "快捷指令大全" quick_launcher_v6.py
"""

import subprocess
import ctypes
import threading

import tkinter as tk
from tkinter import scrolledtext

# ============================================================
# 工具数据（63项，全部广泛兼容 Win7/10/11）
# 格式: (中文名, 英文名, 执行命令, 分类)
#
# 兼容性策略：
#   1. 优先 .cpl / .msc / .exe（Win7/10/11 全兼容）
#   2. cmd /k 保持窗口不闪退
#   3. 不用任何已废弃命令
# ============================================================
TOOLS = [
    # ── 系统工具 (14) ──
    ("命令提示符",          "cmd",                     "cmd",                    "系统工具"),
    ("管理员CMD",           "elevated cmd",           "powershell -Command \"Start-Process cmd -Verb RunAs\"", "系统工具"),
    ("PowerShell",          "powershell",             "powershell",             "系统工具"),
    ("注册表编辑器",         "regedit",                "regedit",                "系统工具"),
    ("系统配置",            "msconfig",               "msconfig",               "系统工具"),
    ("系统信息",            "msinfo32",               "msinfo32",               "系统工具"),
    ("系统属性(综合)",      "sysdm.cpl hub",         "sysdm.cpl",              "系统工具"),
    ("Windows版本",         "winver",                 "winver",                 "系统工具"),
    ("系统还原",            "rstrui",                 "rstrui",                 "系统工具"),
    ("环境变量编辑",         "environment variables",   "rundll32.exe sysdm.cpl,EditEnvironmentVariables", "系统工具"),
    ("Windows更新(综合)",   "windows update hub",     "control /name Microsoft.WindowsUpdate", "系统工具"),
    ("备份还原",            "sdclt",                  "sdclt",                  "系统工具"),
    ("事件查看器",          "eventvwr.msc",           "eventvwr.msc",           "系统工具"),
    ("可靠性蓝屏记录",       "perfmon /rel",           "perfmon /rel",           "系统工具"),

    # ── 硬件与设备 (9) ──
    ("设备管理器(综合)",    "devmgmt.msc hub",       "devmgmt.msc",            "硬件与设备"),
    ("磁盘管理",            "diskmgmt.msc",           "diskmgmt.msc",           "硬件与设备"),
    ("显示设置",            "desk.cpl",               "desk.cpl",               "硬件与设备"),
    ("鼠标属性",            "main.cpl",               "main.cpl",               "硬件与设备"),
    ("键盘属性",            "control keyboard",        "control keyboard",        "硬件与设备"),
    ("电源选项",            "powercfg.cpl",           "powercfg.cpl",           "硬件与设备"),
    ("设备和打印机",        "control printers",        "control printers",        "硬件与设备"),
    ("声音设置",            "mmsys.cpl",              "mmsys.cpl",              "硬件与设备"),
    ("自动播放设置",         "control autoplay",        "control /name Microsoft.AutoPlay", "硬件与设备"),

    # ── 服务与进程 (5) ──
    ("系统服务",            "services.msc",           "services.msc",           "服务与进程"),
    ("任务管理器",          "taskmgr",                "taskmgr",                "服务与进程"),
    ("性能监视器",          "perfmon.msc",            "perfmon.msc",            "服务与进程"),
    ("资源监视器",          "resmon",                 "resmon",                 "服务与进程"),
    ("计划任务",            "taskschd.msc",           "taskschd.msc",           "服务与进程"),

    # ── 网络 (6) ──
    ("网络连接",            "ncpa.cpl",               "ncpa.cpl",               "网络"),
    ("防火墙设置",          "wf.msc",                 "wf.msc",                 "网络"),
    ("本机IP地址",          "ipconfig",               "cmd /k ipconfig /all",    "网络"),
    ("远程桌面",            "mstsc",                  "mstsc",                  "网络"),
    ("远程协助",            "msra",                   "msra",                   "网络"),
    ("网络和共享中心",       "NetworkAndSharingCenter", "control /name Microsoft.NetworkAndSharingCenter", "网络"),

    # ── 程序和功能 (5) ──
    ("程序和功能",          "appwiz.cpl",             "appwiz.cpl",             "程序和功能"),
    ("默认程序",            "DefaultPrograms",        "control /name Microsoft.DefaultPrograms", "程序和功能"),
    ("启动文件夹",          "shell:startup",          "explorer shell:startup",  "程序和功能"),
    ("字体文件夹",          "shell:fonts",            "explorer shell:fonts",    "程序和功能"),
    ("管理可选功能",         "optionalfeatures",       "optionalfeatures",        "程序和功能"),

    # ── 辅助工具 (10) ──
    ("计算器",              "calc",                   "calc",                   "辅助工具"),
    ("画图",                "mspaint",                "mspaint",                "辅助工具"),
    ("记事本",              "notepad",                "notepad",                "辅助工具"),
    ("屏幕键盘",            "osk",                    "osk",                    "辅助工具"),
    ("字符映射表",           "charmap",                "charmap",                "辅助工具"),
    ("磁盘清理",            "cleanmgr",               "cleanmgr",               "辅助工具"),
    ("截图工具",            "snippingtool",           "snippingtool",           "辅助工具"),
    ("步骤记录器",          "psr",                    "psr",                    "辅助工具"),
    ("辅助功能",            "utilman",                "utilman",                "辅助工具"),
    ("讲述人",              "narrator",               "narrator",               "辅助工具"),
    ("锁屏",                "LockWorkStation",        "rundll32.exe user32.dll,LockWorkStation", "辅助工具"),

    # ── 维护与诊断 (10) ──
    ("最近文件",            "shell:recent",           "explorer shell:recent",   "维护与诊断"),
    ("下载文件夹",           "shell:downloads",        "explorer shell:downloads", "维护与诊断"),
    ("临时文件夹",           "temp",                   "explorer %temp%",         "维护与诊断"),
    ("桌面文件夹",           "shell:desktop",          "explorer shell:desktop",  "维护与诊断"),
    ("AppData文件夹",       "appdata",                "explorer %appdata%",      "维护与诊断"),
    ("DirectX诊断",         "dxdiag",                 "dxdiag",                 "维护与诊断"),
    ("磁盘碎片整理",         "dfrgui",                 "dfrgui",                 "维护与诊断"),
    ("系统激活状态",         "slmgr /xpr",            "cmd /k slmgr.vbs /xpr",  "维护与诊断"),
    ("存储感知",            "ms-settings:storagesense","ms-settings:storagesense","维护与诊断"),
    ("文档目录",            "Documents",              "explorer %userprofile%\\Documents", "维护与诊断"),

    # ── 休眠唤醒排查 (3) ──
    ("上次唤醒设备",         "powercfg -lastwake",     "cmd /k powercfg -lastwake",     "休眠唤醒排查"),
    ("可唤醒设备列表",        "powercfg wake_armed",    "cmd /k powercfg -devicequery wake_armed", "休眠唤醒排查"),
    ("所有唤醒设备详情",      "powercfg wake_from_any", "cmd /k powercfg -devicequery wake_from_any", "休眠唤醒排查"),
]

CATEGORY_ORDER = [
    "系统工具", "硬件与设备", "服务与进程", "网络",
    "程序和功能", "辅助工具", "维护与诊断", "休眠唤醒排查"
]

# ============================================================
# 样式常量
# ============================================================
BG        = "#080808"
BG2       = "#0d1117"
HOVER     = "#162b16"
GREEN     = "#00ff41"
DIM       = "#1a7a2a"
GREY      = "#0a0a0a"
BTN_W     = 320
BTN_H     = 52
BTN_PER_ROW = 3

FONT_TITLE = ("Consolas", 18, "bold")
FONT_BTN   = ("Consolas", 11)
FONT_BTN_S = ("Consolas", 9)
FONT_LOG   = ("Consolas", 9)
FONT_NUM   = ("Consolas", 9)
FONT_EN    = ("Consolas", 8)

# ============================================================
# 启动工具（广泛兼容写法）
# ============================================================
def launch(name: str, raw: str):
    try:
        if raw.startswith("cmd /k "):
            cmd = f'cmd /c start "" {raw}'
        elif raw.startswith("cmd /c "):
            cmd = f'cmd /c start "" {raw[6:]}'
        elif raw.startswith("powershell"):
            cmd = f'cmd /c start "" {raw}'
        else:
            cmd = f'cmd /c start "" {raw}'
        subprocess.Popen(cmd, shell=True,
                        creationflags=0x08000000)
        log(f"[OK] {name}")
    except Exception as e:
        log(f"[ERR] {name} -> {e}")

def launch_thread(name: str, raw: str):
    threading.Thread(target=launch, args=(name, raw), daemon=True).start()

# ============================================================
# 日志
# ============================================================
_log_widget = None
def log(msg: str):
    global _log_widget
    if _log_widget is None:
        return
    try:
        _log_widget.configure(state="normal")
        _log_widget.insert("end", msg + "\n")
        _log_widget.see("end")
        _log_widget.configure(state="disabled")
    except:
        pass

# ============================================================
# 管理员检测
# ============================================================
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except:
        return False

# ============================================================
# 丝滑动画按钮（自绘 Canvas，无残影）
# ============================================================
class SmoothButton(tk.Canvas):
    def __init__(self, parent, idx: int, name: str, en_name: str, cmd: str, on_click, **kw):
        super().__init__(parent, highlightthickness=0, **kw)
        self.idx = idx
        self.name = name
        self.en_name = en_name
        self.cmd = cmd
        self.on_click = on_click

        self.configure(width=BTN_W, height=BTN_H, bg=BG2, relief="flat")
        self._animating = False
        self._hover_progress = 0.0
        self._target = 0.0

        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)
        self.bind("<ButtonRelease-1>", self._on_release)

        self._draw()

    def _draw(self):
        self.delete("all")
        p = self._hover_progress
        bg = self._lerp_color(BG2, HOVER, p)
        bc = self._lerp_color(DIM, GREEN, p)
        fc = self._lerp_color(GREEN, "#00ff88", p)
        ec = self._lerp_color(DIM, "#228b22", p)

        self.create_rectangle(0, 0, BTN_W, BTN_H, fill=bg, outline="", tags="bg")
        self.create_rectangle(0, 0, 3, BTN_H, fill=bc, outline="", tags="lborder")
        self.create_rectangle(1, 1, BTN_W-1, BTN_H-1, fill="", outline=bc, width=1, tags="border")
        self.create_text(12, BTN_H//2 - 8, text=f"#{self.idx:>3}",
                         anchor="w", font=FONT_NUM, fill=self._lerp_color(DIM, GREEN, p), tags="num")
        self.create_text(68, BTN_H//2 - 8, text=self.name,
                         anchor="w", font=FONT_BTN, fill=fc, tags="label")
        self.create_text(68, BTN_H//2 + 10, text=self.en_name,
                         anchor="w", font=FONT_EN, fill=ec, tags="enlabel")
        self.create_text(BTN_W-14, BTN_H//2, text="▶",
                         anchor="e", font=FONT_BTN_S, fill=self._lerp_color(DIM, GREEN, p), tags="arrow")

    def _lerp_color(self, c1: str, c2: str, t: float) -> str:
        r1, g1, b1 = int(c1[1:3],16), int(c1[3:5],16), int(c1[5:7],16)
        r2, g2, b2 = int(c2[1:3],16), int(c2[3:5],16), int(c2[5:7],16)
        r = int(r1 + (r2-r1)*t)
        g = int(g1 + (g2-g1)*t)
        b = int(b1 + (b2-b1)*t)
        return f"#{r:02x}{g:02x}{b:02x}"

    def _on_enter(self, e=None):
        self._target = 1.0
        if not self._animating:
            self._animate()

    def _on_leave(self, e=None):
        self._target = 0.0
        if not self._animating:
            self._animate()

    def _animate(self):
        self._animating = True
        step = 0.10
        if self._target == 1.0:
            self._hover_progress = min(1.0, self._hover_progress + step)
        else:
            self._hover_progress = max(0.0, self._hover_progress - step)
        self._draw()
        if abs(self._hover_progress - self._target) > 0.01:
            self.after(16, self._animate)
        else:
            self._hover_progress = self._target
            self._draw()
            self._animating = False

    def _on_click(self, e=None):
        self._hover_progress = 1.0
        self._draw()
        self.on_click(self.name, self.cmd)

    def _on_release(self, e=None):
        x, y = e.x, e.y
        if 0 <= x <= BTN_W and 0 <= y <= BTN_H:
            self._target = 1.0
        else:
            self._target = 0.0
        self._animate()

# ============================================================
# 主应用
# ============================================================
class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("快捷指令大全 v6.0")
        self.root.geometry("1120x760")
        self.root.minsize(1000, 620)
        self.root.configure(bg=BG)
        self.root.resizable(True, True)

        self.indexed = [(i, n, e, c, cat) for i, (n, e, c, cat) in enumerate(TOOLS, 1)]
        self.cat_counts = {}
        for _, _, _, _, cat in self.indexed:
            self.cat_counts[cat] = self.cat_counts.get(cat, 0) + 1

        self.current_category = "全部"
        self.search_keyword = ""

        self._build()
        self._refresh_buttons()

        self.root.bind("<Control-f>", lambda e: self.search_entry.focus_set())
        self.root.bind("<Escape>", lambda e: self._clear_search())

        log("=" * 58)
        log("  快捷指令大全 v6.0 [最终稳定版]")
        log(f"  管理员: {'是' if is_admin() else '否（建议右键以管理员身份运行）'}")
        log(f"  工具总数: {len(TOOLS)}")
        log("=" * 58)

    def _build(self):
        self._header()
        self._toolbar()
        self._main()
        self._log_section()
        self._statusbar()

    def _header(self):
        f = tk.Frame(self.root, bg=BG, height=52)
        f.pack(fill="x", padx=14, pady=(10, 2))
        f.pack_propagate(False)
        tk.Label(f, text="▶ 快捷指令大全  v6.0",
                 font=FONT_TITLE, fg=GREEN, bg=BG, anchor="w"
                 ).pack(side="left", fill="both", expand=True)
        tk.Label(f, text="[ FINAL STABLE ]",
                 font=FONT_BTN_S, fg=DIM, bg=BG, anchor="e"
                 ).pack(side="right")
        tk.Frame(self.root, bg=DIM, height=1).pack(fill="x", padx=14)

    def _toolbar(self):
        bar = tk.Frame(self.root, bg=BG)
        bar.pack(fill="x", padx=14, pady=4)

        sf = tk.Frame(bar, bg=BG)
        sf.pack(side="left", fill="x", expand=True)
        tk.Label(sf, text="🔍", font=FONT_BTN, bg=BG, fg=GREEN).pack(side="left", padx=(0,4))

        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *a: self._on_search())
        self.search_entry = tk.Entry(
            sf, textvariable=self.search_var,
            font=FONT_BTN, fg=DIM, bg=GREY,
            insertbackground=GREEN, relief="flat",
            highlightbackground=DIM, highlightcolor=GREEN, highlightthickness=1,
        )
        self.search_entry.pack(side="left", fill="x", expand=True, ipady=3)
        self.search_entry.insert(0, "输入关键字搜索...")
        self.search_entry.bind("<FocusIn>", self._on_focus_in)
        self.search_entry.bind("<FocusOut>", self._on_focus_out)

        cf = tk.Frame(bar, bg=BG)
        cf.pack(side="right", padx=(10, 0))
        tk.Label(cf, text="分类:", font=FONT_BTN_S, fg=GREEN, bg=BG).pack(side="left", padx=(0,4))

        self.cat_var = tk.StringVar(value="全部")
        om = tk.OptionMenu(cf, self.cat_var, *(["全部"] + CATEGORY_ORDER),
                            command=self._on_cat_menu)
        om.config(font=FONT_BTN_S, fg=GREEN, bg=BG2,
                  activebackground=HOVER, activeforeground=GREEN,
                  highlightbackground=DIM, highlightthickness=1,
                  relief="flat", borderwidth=0)
        om["menu"].config(font=FONT_BTN_S, fg=GREEN, bg=BG2,
                          activebackground=HOVER, activeforeground=GREEN, tearoff=0)
        om.pack(side="left")

    def _main(self):
        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=14, pady=4)

        left = tk.Frame(main, bg=BG, width=155)
        left.pack(side="left", fill="y", padx=(0,10))
        left.pack_propagate(False)

        tk.Label(left, text="— 分类导航 —", font=FONT_BTN_S, fg=DIM, bg=BG
                 ).pack(anchor="w", pady=(0,4))

        self.cat_label_map = {}
        for cat in CATEGORY_ORDER:
            cnt = self.cat_counts.get(cat, 0)
            lbl = tk.Label(left, text=f"  {cat} ({cnt})",
                           font=FONT_BTN_S, fg=GREEN, bg=BG,
                           anchor="w", cursor="hand2", padx=4, pady=2)
            lbl.pack(fill="x", pady=0)
            lbl.bind("<Button-1>", lambda e, c=cat: self._set_category(c))
            lbl.bind("<Enter>", lambda e, l=lbl: l.config(bg=HOVER, fg="#00ff88"))
            lbl.bind("<Leave>", lambda e, l=lbl, c=cat:
                     l.config(bg=BG, fg=GREEN) if self.current_category != c else None)
            self.cat_label_map[cat] = lbl

        right = tk.Frame(main, bg=BG)
        right.pack(side="left", fill="both", expand=True)

        self.canvas = tk.Canvas(right, bg=BG, highlightthickness=0)
        self.sb = tk.Scrollbar(right, orient="vertical", command=self.canvas.yview,
                                bg=BG, troughcolor=BG, activebackground=DIM, width=12)
        self.sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas.configure(yscrollcommand=self.sb.set)

        self.btn_frame = tk.Frame(self.canvas, bg=BG)
        self.cw = self.canvas.create_window((0, 0), window=self.btn_frame, anchor="nw")
        self.btn_frame.bind("<Configure>",
                            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>",
                         lambda e: self.canvas.itemconfig(self.cw, width=e.width))
        self.canvas.bind_all("<MouseWheel>", self._on_wheel)

    def _log_section(self):
        tk.Frame(self.root, bg=DIM, height=1).pack(fill="x", padx=14, pady=(4,0))
        hf = tk.Frame(self.root, bg=BG, height=20)
        hf.pack(fill="x", padx=14, pady=(3,0))
        tk.Label(hf, text="▌执行日志", font=FONT_BTN_S, fg=DIM, bg=BG, anchor="w"
                 ).pack(side="left")
        tk.Frame(self.root, bg=DIM, height=1).pack(fill="x", padx=14)

        self.log_text = scrolledtext.ScrolledText(
            self.root, height=5, font=FONT_LOG, fg=GREEN, bg=GREY,
            insertbackground=GREEN, relief="flat",
            highlightbackground=DIM, highlightthickness=1, wrap="word",
        )
        self.log_text.pack(fill="x", padx=14, pady=(2, 3))
        self.log_text.configure(state="disabled")

    def _statusbar(self):
        self.status_var = tk.StringVar(value="就绪 | 共 {} 个工具 | Ctrl+F 搜索 | Esc 清除".format(len(TOOLS)))
        tk.Label(self.root, textvariable=self.status_var,
                 font=FONT_BTN_S, fg=DIM, bg=BG, anchor="w",
                 padx=14, pady=1).pack(fill="x", side="bottom")

    # ==================== 按钮渲染 ====================
    def _refresh_buttons(self):
        for w in self.btn_frame.winfo_children():
            w.destroy()

        kw = self.search_keyword.strip().lower()
        cat_f = self.current_category

        filtered = [t for t in self.indexed
                    if (cat_f == "全部" or t[4] == cat_f)
                    and (not kw or kw in t[1].lower() or kw in t[2].lower() or kw in t[3].lower())]

        if not filtered:
            tk.Label(self.btn_frame, text="[ 没有找到匹配的工具 ]",
                     font=FONT_BTN, fg=DIM, bg=BG).pack(pady=20)
            self.status_var.set(f"筛选: 0 个 | 关键字: '{kw}' | 分类: {cat_f}")
            return

        grouped = {}
        if kw:
            grouped["搜索结果"] = filtered
        else:
            for t in filtered:
                grouped.setdefault(t[4], []).append(t)

        order = ["搜索结果"] if kw else [c for c in CATEGORY_ORDER if c in grouped]

        for gname in order:
            items = grouped[gname]
            tf = tk.Frame(self.btn_frame, bg=BG)
            tf.pack(fill="x", pady=(8, 2))
            tk.Label(tf, text=f"┌─ {gname} ({len(items)}) ─",
                     font=FONT_BTN_S, fg=DIM, bg=BG, anchor="w"
                     ).pack(side="left", fill="x", expand=True)

            grid = tk.Frame(self.btn_frame, bg=BG)
            grid.pack(fill="x", padx=2)
            for i, (idx, name, en, cmd, cat) in enumerate(items):
                r, c = divmod(i, BTN_PER_ROW)
                btn = SmoothButton(
                    grid, idx=idx, name=name, en_name=en, cmd=cmd,
                    on_click=self._on_btn_click, bg=BG2,
                )
                btn.grid(row=r, column=c, padx=4, pady=3, sticky="nsew")
            for c in range(BTN_PER_ROW):
                grid.columnconfigure(c, weight=1, uniform="btncol")

        self.status_var.set(f"显示: {len(filtered)} 个 | 关键字: '{kw}' | 分类: {cat_f}")
        self.canvas.yview_moveto(0)

    # ==================== 事件 ====================
    def _on_btn_click(self, name: str, cmd: str):
        log(f"[点击] {name}")
        launch_thread(name, cmd)

    def _on_search(self):
        v = self.search_var.get()
        self.search_keyword = "" if v == "输入关键字搜索..." else v
        self._refresh_buttons()

    def _on_focus_in(self, e):
        if self.search_entry.get() == "输入关键字搜索...":
            self.search_entry.delete(0, "end")
            self.search_entry.config(fg=GREEN)

    def _on_focus_out(self, e):
        if not self.search_entry.get():
            self.search_entry.insert(0, "输入关键字搜索...")
            self.search_entry.config(fg=DIM)

    def _clear_search(self):
        self.search_var.set("")
        self.search_keyword = ""
        self._refresh_buttons()
        self.root.focus_set()

    def _on_cat_menu(self, value):
        self._set_category(value)

    def _set_category(self, cat: str):
        self.current_category = cat
        self.cat_var.set(cat)
        for c, lbl in self.cat_label_map.items():
            if c == cat:
                lbl.config(bg=HOVER, fg="#00ff88")
            else:
                lbl.config(bg=BG, fg=GREEN)
        self._refresh_buttons()

    def _on_wheel(self, e):
        self.canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")

# ============================================================
# 入口
# ============================================================
def main():
    global _log_widget
    root = tk.Tk()
    app = App(root)
    _log_widget = app.log_text
    root.mainloop()

if __name__ == "__main__":
    main()
