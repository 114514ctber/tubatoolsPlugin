# 快捷指令大全 v6.0

> 一个开源免费的 Windows 系统快捷指令启动器，黑底绿字黑客风格界面，63 个常用系统工具一键直达。

## 快速开始 / Quick Start

**方式一：直接运行（推荐）**
下载 `快捷指令大全_v6.exe`，双击即可运行。无需安装任何东西。

**方式二：自行打包**
进入"上传资料"文件夹，按"使用说明.txt"中的步骤操作。需要提前安装 Python 3.8+ 环境。

## 功能简介 / Features

- **63 个系统工具**，7 大分类
- **黑底绿字黑客风格**，丝滑动画按钮
- **中英双语标注**，搜索框实时过滤
- **广泛兼容**：Windows 7 / 10 / 11
- **零依赖**：exe 双击即用

## 工具分类 / Categories

| 分类 Category | 数量 Count |
|---|---|
| 系统工具 System Tools | 14 |
| 硬件与设备 Hardware & Devices | 9 |
| 服务与进程 Services & Processes | 5 |
| 网络 Network | 6 |
| 程序和功能 Programs & Features | 5 |
| 辅助工具 Accessibility | 11 |
| 维护与诊断 Maintenance & Diagnostics | 10 |
| 休眠唤醒排查 Wake Source | 3 |

## 使用说明 / User Guide

详见仓库内 `使用说明.txt`（中英双语）。

## 开源协议 / License

MIT License

---

## ⚠️ 免责声明 / Disclaimer

### 软件免责声明 / Software Disclaimer

1. 本软件按"现状"提供，不附带任何形式的明示或暗示担保。
   Provided "as is", without warranty of any kind.

2. 用户自行承担使用本软件的全部风险。
   Use at your own risk.

3. 部分功能涉及系统级操作（注册表、磁盘管理等），误操作可能导致系统不稳定。请谨慎使用。
   Some tools access system-level functions. Use with caution.

4. 以管理员身份运行即表示您理解并接受相关风险。
   Running as admin means you accept the risks.

5. 不适用于医疗、航空、核设施等高风险场景。
   Not for medical, aviation, nuclear, or other high-risk use.

### 捐赠说明 / Donation Notice

1. 本软件完全免费，捐赠纯属自愿。
   Software is free. Donations are voluntary.

2. 建议金额 1~10 元人民币。
   Suggested amount: 1~10 RMB.

3. 付款前请慎重考虑。作者为学生，课余时间有限，繁忙时期可能无法及时处理退款请求，也存在遗忘或延迟回复的情况。请在付款前务必确认。
   Please consider carefully before paying. The author is a student with limited free time. Refund requests may not be processed promptly during busy periods.

4. 捐赠不等于获得技术支持承诺。
   Donations do not guarantee technical support.

5. 捐赠者自行承担相关税务责任（如有）。
   Donors are responsible for any tax obligations.

---

## 关于作者 / About the Author

- **姓名 Name**：程佳乐
- **出生日期 DOB**：2009 年 9 月 1 日
- **身份**：在校学生 / 编程爱好者
- **项目定位**：个人学习项目，免费开源分享

## 联系方式 / Contact

详见 `使用说明.txt` 中的"联系方式"板块。

---

**感谢使用，祝你折腾愉快！ 🚀**
**Thanks for using! Have fun! 🚀**
