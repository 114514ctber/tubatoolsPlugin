@echo off
title �����ݷ�ʽ�������ߣ�

>nul 2>&1 REG.exe query "HKU\S-1-5-19" || (
    ECHO SET UAC = CreateObject^("Shell.Application"^) > "%TEMP%\Getadmin.vbs"
    ECHO UAC.ShellExecute "%~f0", "%1", "", "runas", 1 >> "%TEMP%\Getadmin.vbs"
    "%TEMP%\Getadmin.vbs"
    DEL /f /q "%TEMP%\Getadmin.vbs" 2>nul
    Exit /b
)

if /i "%PROCESSOR_IDENTIFIER:~0,3%" == "X86"  goto inx86
if /i "%PROCESSOR_IDENTIFIER:~0,3%" NEQ "X86" goto inx64

:inx86

mshta VBScript:Execute("Set a=CreateObject(""WScript.Shell""):Set b=a.CreateShortcut(a.SpecialFolders(""Desktop"") & ""\NTPWEdit.lnk""):b.TargetPath=""%~dp0NTPWEdit\ntpwedit.exe"":b.WorkingDirectory=""%~dp0NTPWEdit\"":b.Save:close")

:inx64

mshta VBScript:Execute("Set a=CreateObject(""WScript.Shell""):Set b=a.CreateShortcut(a.SpecialFolders(""Desktop"") & ""\NTPWEdit.lnk""):b.TargetPath=""%~dp0NTPWEdit\ntpwedit64.exe"":b.WorkingDirectory=""%~dp0NTPWEdit\"":b.Save:close")